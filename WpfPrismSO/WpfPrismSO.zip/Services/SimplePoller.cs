﻿using System.Threading;
using System.Threading.Tasks;
using WpfPrismSO.Core;

namespace WpfPrismSO.Services
{
    public class SimplePoller : IPoller
    {
        public SimplePoller()
        {
            //BeginPolling();
        }

        public void BeginPolling()
        {
            int delay = 5000;
            var cancellationTokenSource = new CancellationTokenSource();
            var token = cancellationTokenSource.Token;
            var listener = Task.Factory.StartNew(() =>
            {
                while (true)
                {
                    //poll HW
                    Log.Info($"Polling...");
                    Thread.Sleep(delay);
                    if (token.IsCancellationRequested)
                        break;
                }

                //cleanup
            }, token, TaskCreationOptions.LongRunning, TaskScheduler.Default);
        }
    }

    public interface IPoller {
        void BeginPolling();
    }
}
