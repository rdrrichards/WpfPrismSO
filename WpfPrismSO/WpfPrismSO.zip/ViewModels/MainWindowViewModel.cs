﻿using Prism.Commands;
using Prism.Mvvm;
using System.Windows;
using System;

namespace WpfPrismSO.ViewModels
{
    public class MainWindowViewModel : BindableBase
    {
        private string _name;

        public MainWindowViewModel()
        {
            BoundCommand = new DelegateCommand<DragEventArgs>(DoWork);
            BoundCommand2 = new DelegateCommand(DoWork2);
            BoundCommand3 = new DelegateCommand(DoWork3);
        }

        private void DoWork3()
        {
            MVFieldToBindTo = "Cum Bubbles!!";
        }

        private void DoWork2()
        {
            MVFieldToBindTo = "Bubble Yum!!";
        }

        private void DoWork(DragEventArgs e)
        {
            MVFieldToBindTo = "Juicy Friut!";
        }

        public DelegateCommand<DragEventArgs> BoundCommand { get; set; }
        public DelegateCommand BoundCommand2 { get; set; }
        public DelegateCommand BoundCommand3 { get; set; }
        public string MVFieldToBindTo { get { return _name; } set { SetProperty(ref _name, value); } }
    }
}
